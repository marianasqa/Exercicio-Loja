package DAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Date;
import javax.swing.JOptionPane;
import classes.produtos;
import JDBC.JDBC;

public class dao_produtos {
    public void create(produtos prod){
        
        Connection con = JDBC.getConnection();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO PRODUTOS (COD_PROD,PRECO_VENDA,DESCRICAO,DATA_VALIDADE,PRECO_CUSTO,ESTOQUE) VALUES (?,?,?,?,?,?)");
            stmt.setInt(1,prod.getCod());
            stmt.setFloat(2,prod.getPreco_venda());
            stmt.setFloat(3,prod.getPreco_custo());
            stmt.setDate(4, (Date) prod.getData());
            stmt.setString(5,prod.getDescricao());
            stmt.setInt(6,prod.getEstoque());
   

            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cliente salvo com sucesso!");        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: "+ex);
        } finally {
            JDBC.closeConnection(con, stmt);
        }
    
    }
}
